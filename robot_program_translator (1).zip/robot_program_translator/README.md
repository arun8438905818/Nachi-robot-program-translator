# Robot Program Translator

A local web app for translating comments in text-based industrial robot program listings.

## Features
- Upload text-based listings such as `.000`, `.txt`, and `.src`.
- Translate text inside `REM["..."]` comments only.
- Preserve the rest of each line as far as possible.
- Review/edit the result and download a UTF-8 text file.
- Supports selecting a target language, with English as the default.

## Windows setup
1. Install Python 3.10 or newer from https://www.python.org/downloads/.
2. Extract this ZIP file.
3. Open Command Prompt in the extracted `robot_program_translator` folder.
4. Run:
   ```bat
   python -m venv .venv
   .venv\Scripts\activate
   pip install -r requirements.txt
   set OPENAI_API_KEY=YOUR_API_KEY_HERE
   python app.py
   ```
5. Open http://127.0.0.1:5000 in your browser.

Optional model override: `set OPENAI_MODEL=gpt-4.1-mini`

## Important limitations and safety
- This is a starter app, not a certified industrial tool.
- It only recognizes comment text in the pattern `REM["..."]`. Adjust the parser for other controller formats.
- Some controller files are binary. Export/print the program list as text before uploading.
- Encoding detection is best-effort; garbled text can still be decoded incorrectly.
- The downloaded file is UTF-8 text and may not be directly loadable by the controller.
- Keep the original file, compare every change, and test on a non-production copy before use.
- Do not place your API key in browser JavaScript or expose this development server publicly. Public deployment requires authentication, HTTPS, rate limits, and additional security.
- OpenAI API usage may incur charges.
